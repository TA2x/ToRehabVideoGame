This font is free and can be distributed freely. If possible, you can indicate the author of the font.
You can use this font for non-commercial and commercial purposes.

Font characteristics:
	Name: [LazyFox Pixel Font 7]
	Monospace: false
	Colored: false
	Size: 8 # may be incorrect
	Default width: 3px (Min:1 Max:5)
	Content: [Symbols][Numbers][Eng letters]

Font author: LazyFox
https://lazy-fox.itch.io/